// Flux Package Manager for WebTerm
// Version 1.0.0

(function() {
  'use strict';

  // Check if WTapi is available
  if (typeof WTapi === 'undefined') {
    console.error('Flux: WTapi not found. Cannot initialize Flux package manager.');
    return;
  }

  // Flux configuration
  const FLUX_CONFIG = {
    registryUrl: 'https://hpkproject.github.io/WebTerm-Pkgs/all.json',
    version: '1.0.0'
  };

  // Package cache
  let packageRegistry = null;

  // Fetch package registry
  async function fetchRegistry() {
    if (packageRegistry) return packageRegistry;
    
    try {
      const response = await fetch(FLUX_CONFIG.registryUrl);
      if (!response.ok) throw new Error('Failed to fetch registry');
      packageRegistry = await response.json();
      return packageRegistry;
    } catch (error) {
      throw new Error(`Could not fetch package registry: ${error.message}`);
    }
  }

  // Find package in registry
  async function findPackage(pkgName) {
    const registry = await fetchRegistry();
    return registry.find(pkg => pkg.name === pkgName);
  }

  // Flux install command
  async function fluxInstall(args) {
    if (args.length === 0) {
      WTapi.print.error('Usage: flux install <package-name>');
      return;
    }

    const pkgName = args[0];
    
    // Check if already installed
    if (WTapi.package.exists(pkgName, 'usr/pkgs')) {
      WTapi.print.warning(`Package '${pkgName}' is already installed.`);
      WTapi.print.text('Use "flux reinstall" to reinstall.', 'gray');
      return;
    }

    WTapi.print.text(`Installing ${pkgName}...`, 'cyan');
    
    try {
      // Find package in registry
      const pkg = await findPackage(pkgName);
      
      if (!pkg) {
        WTapi.print.error(`Package '${pkgName}' not found in registry.`);
        WTapi.print.text('Use "flux search" to list available packages.', 'gray');
        return;
      }

      // Show package info
      if (pkg.description) {
        WTapi.print.text(`Description: ${pkg.description}`, 'gray');
      }
      if (pkg.version) {
        WTapi.print.text(`Version: ${pkg.version}`, 'gray');
      }

      // Install package
      const success = await WTapi.package.install(pkgName, pkg.url, 'usr/pkgs');
      
      if (success) {
        WTapi.print.success(`✓ Successfully installed ${pkgName}`);
        if (pkg.author) {
          WTapi.print.text(`Author: ${pkg.author}`, 'gray');
        }
      }
    } catch (error) {
      WTapi.print.error(`Failed to install ${pkgName}: ${error.message}`);
    }
  }

  // Flux uninstall command
  async function fluxUninstall(args) {
    if (args.length === 0) {
      WTapi.print.error('Usage: flux uninstall <package-name>');
      return;
    }

    const pkgName = args[0];
    
    if (!WTapi.package.exists(pkgName, 'usr/pkgs')) {
      WTapi.print.error(`Package '${pkgName}' is not installed.`);
      return;
    }

    WTapi.print.text(`Uninstalling ${pkgName}...`, 'yellow');
    
    // Remove any commands registered by this package
    const commands = WTapi.command.list();
    const pkgCommands = commands.filter(cmd => {
      // Try to identify commands that might belong to this package
      // This is a simple heuristic
      return cmd.startsWith(pkgName);
    });

    pkgCommands.forEach(cmd => {
      WTapi.command.unregister(cmd);
      WTapi.print.text(`  Removed command: ${cmd}`, 'gray');
    });

    const success = WTapi.package.uninstall(pkgName, 'usr/pkgs');
    
    if (success) {
      WTapi.print.success(`✓ Successfully uninstalled ${pkgName}`);
    }
  }

  // Flux list command
  async function fluxList(args) {
    const installed = WTapi.package.list('usr/pkgs');
    
    if (installed.length === 0) {
      WTapi.print.text('No packages installed.', 'gray');
      WTapi.print.text('Use "flux search" to browse available packages.', 'gray');
      return;
    }

    WTapi.print.text('Installed packages:', 'cyan');
    WTapi.print.text('');
    
    installed.forEach(pkgName => {
      const files = WTapi.fs.read.dir(`usr/pkgs/${pkgName}`);
      const fileCount = files ? files.length : 0;
      WTapi.print.text(`  • ${pkgName} (${fileCount} files)`, 'white');
    });
    
    WTapi.print.text('');
    WTapi.print.text(`Total: ${installed.length} package(s)`, 'gray');
  }

  // Flux search command
  async function fluxSearch(args) {
    WTapi.print.text('Fetching package registry...', 'cyan');
    
    try {
      const registry = await fetchRegistry();
      
      const searchTerm = args.join(' ').toLowerCase();
      let results = registry;
      
      if (searchTerm) {
        results = registry.filter(pkg => 
          pkg.name.toLowerCase().includes(searchTerm) ||
          (pkg.description && pkg.description.toLowerCase().includes(searchTerm))
        );
      }

      if (results.length === 0) {
        WTapi.print.text('No packages found.', 'gray');
        return;
      }

      WTapi.print.text('');
      WTapi.print.text('Available packages:', 'cyan');
      WTapi.print.text('');
      
      results.forEach(pkg => {
        const installed = WTapi.package.exists(pkg.name) ? ' [INSTALLED]' : '';
        WTapi.print.text(`  ${pkg.name}${installed}`, 'white');
        if (pkg.version) {
          WTapi.print.text(`    Version: ${pkg.version}`, 'gray');
        }
        if (pkg.description) {
          WTapi.print.text(`    ${pkg.description}`, 'gray');
        }
        WTapi.print.text('');
      });
      
      WTapi.print.text(`Found ${results.length} package(s)`, 'gray');
    } catch (error) {
      WTapi.print.error(`Failed to search packages: ${error.message}`);
    }
  }

  // Flux info command
  async function fluxInfo(args) {
    if (args.length === 0) {
      WTapi.print.error('Usage: flux info <package-name>');
      return;
    }

    const pkgName = args[0];
    
    try {
      const pkg = await findPackage(pkgName);
      
      if (!pkg) {
        WTapi.print.error(`Package '${pkgName}' not found in registry.`);
        return;
      }

      const installed = WTapi.package.exists(pkgName, 'usr/pkgs');
      
      WTapi.print.text('');
      WTapi.print.text(`Package: ${pkg.name}`, 'cyan');
      WTapi.print.text('─'.repeat(50), 'gray');
      
      if (pkg.version) {
        WTapi.print.text(`Version: ${pkg.version}`, 'white');
      }
      if (pkg.author) {
        WTapi.print.text(`Author: ${pkg.author}`, 'white');
      }
      if (pkg.description) {
        WTapi.print.text(`Description: ${pkg.description}`, 'white');
      }
      
      WTapi.print.text(`Status: ${installed ? 'Installed' : 'Not installed'}`, installed ? 'green' : 'gray');
      
      if (installed) {
        const files = WTapi.fs.read.dir(`usr/pkgs/${pkgName}`);
        if (files && files.length > 0) {
          WTapi.print.text('');
          WTapi.print.text('Files:', 'white');
          files.forEach(file => {
            WTapi.print.text(`  • ${file}`, 'gray');
          });
        }
      }
      
      WTapi.print.text('');
    } catch (error) {
      WTapi.print.error(`Failed to get package info: ${error.message}`);
    }
  }

  // Flux update command (refresh registry)
  async function fluxUpdate(args) {
    WTapi.print.text('Updating package registry...', 'cyan');
    packageRegistry = null; // Clear cache
    
    try {
      await fetchRegistry();
      WTapi.print.success('✓ Package registry updated');
    } catch (error) {
      WTapi.print.error(`Failed to update registry: ${error.message}`);
    }
  }

  // Flux reinstall command
  async function fluxReinstall(args) {
    if (args.length === 0) {
      WTapi.print.error('Usage: flux reinstall <package-name>');
      return;
    }

    const pkgName = args[0];
    
    if (WTapi.package.exists(pkgName, 'usr/pkgs')) {
      WTapi.print.text(`Reinstalling ${pkgName}...`, 'yellow');
      await fluxUninstall([pkgName]);
      WTapi.print.text('');
    }
    
    await fluxInstall([pkgName]);
  }

  // Main flux command handler
  async function fluxCommand(args) {
    if (args.length === 0) {
      // Show help
      WTapi.print.text('');
      WTapi.print.text('Flux Package Manager v' + FLUX_CONFIG.version, 'cyan');
      WTapi.print.text('═'.repeat(50), 'cyan');
      WTapi.print.text('');
      WTapi.print.text('Usage:', 'white');
      WTapi.print.text('  flux install <package>    - Install a package', 'gray');
      WTapi.print.text('  flux uninstall <package>  - Uninstall a package', 'gray');
      WTapi.print.text('  flux reinstall <package>  - Reinstall a package', 'gray');
      WTapi.print.text('  flux list                 - List installed packages', 'gray');
      WTapi.print.text('  flux search [term]        - Search available packages', 'gray');
      WTapi.print.text('  flux info <package>       - Show package information', 'gray');
      WTapi.print.text('  flux update               - Update package registry', 'gray');
      WTapi.print.text('  flux help                 - Show this help message', 'gray');
      WTapi.print.text('');
      return;
    }

    const subcommand = args[0].toLowerCase();
    const subArgs = args.slice(1);

    switch (subcommand) {
      case 'install':
      case 'i':
        await fluxInstall(subArgs);
        break;
      case 'uninstall':
      case 'remove':
      case 'rm':
        await fluxUninstall(subArgs);
        break;
      case 'reinstall':
        await fluxReinstall(subArgs);
        break;
      case 'list':
      case 'ls':
        await fluxList(subArgs);
        break;
      case 'search':
      case 'find':
        await fluxSearch(subArgs);
        break;
      case 'info':
      case 'show':
        await fluxInfo(subArgs);
        break;
      case 'update':
      case 'refresh':
        await fluxUpdate(subArgs);
        break;
      case 'help':
      case '--help':
      case '-h':
        await fluxCommand([]);
        break;
      default:
        WTapi.print.error(`Unknown command: flux ${subcommand}`);
        WTapi.print.text('Use "flux help" for available commands', 'gray');
    }
  }

  // Register flux command
  WTapi.command.register('flux', fluxCommand);

  // Print initialization message
  WTapi.print.text(`Flux Package Manager v${FLUX_CONFIG.version} loaded`, 'green');

})();